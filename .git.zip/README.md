In this project i will be creating a password manage Single Webpage Application which makes use of various programming elements such as HTML, CSS, Javascript, and JSON. 

The user will be able to input their username and password alongside for what platform that account will be. This is many to have a safe space to store account details as a large amount of users forget their passwords and it would be ideal to have a place to store them.

I will implement strength checking features to suggest improvements to any passwords a user might have inputted as it could be weak, this will then notify them that they should change it for the specific platform.
